#version 120
#include "/lib/settings.glsl"
#include "/lib/common.glsl"

/* DRAWBUFFERS:0 */
uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform float rainStrength;
uniform float frameTimeCounter;

varying vec3 vViewPos;

float hash31(vec3 p) {
    p = fract(p * 0.1031);
    p += dot(p, p.yzx + 33.33);
    return fract((p.x + p.y) * p.z);
}

void main() {
    vec3 worldDir = safeNormalize((gbufferModelViewInverse * vec4(vViewPos, 0.0)).xyz);
    vec3 sunDir = safeNormalize((gbufferModelViewInverse * vec4(sunPosition, 0.0)).xyz);
    vec3 col = computeSky(worldDir, sunDir, rainStrength);

    float nightVis = (1.0 - smoothstep(-0.14, 0.06, sunDir.y)) * (1.0 - rainStrength);
    if (nightVis > 0.01 && worldDir.y > 0.02) {
        vec3 grid = floor(worldDir * 210.0);
        float rnd = hash31(grid);
        if (rnd > 0.994) {
            float twinkle = 0.65 + 0.35 * sin(frameTimeCounter * 2.5 + rnd * 600.0);
            float horizonFade = smoothstep(0.02, 0.25, worldDir.y);
            col += vec3(0.85, 0.92, 1.0) * twinkle * horizonFade * nightVis * 1.4;
        }
    }

    col = linearToSRGB(acesToneMap(col));
    gl_FragColor = vec4(col, 1.0);
}
