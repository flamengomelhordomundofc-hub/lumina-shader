#version 120
#include "/lib/settings.glsl"
#include "/lib/common.glsl"

/* DRAWBUFFERS:0 */
uniform sampler2D texture;
uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform vec3 shadowLightPosition;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;
uniform float rainStrength;
uniform float far;

varying vec2 vTexcoord;
varying vec2 vLightmap;
varying vec4 vColor;
varying vec3 vWorldNormal;
varying vec3 vViewPos;
varying vec3 vWorldPos;
varying float vIsWater;

vec3 getWaterNormal(vec2 pos, float t) {
    float w1 = sin(pos.x * 2.4 + t * 2.2) * cos(pos.y * 2.1 - t * 1.7);
    float w2 = sin((pos.x * 1.7 - pos.y * 2.5) + t * 2.9);
    float w3 = cos((pos.x * 3.8 + pos.y * 3.2) - t * 3.4);
    float dx = (w1 * 0.45 + w2 * 0.35 + w3 * 0.20) * 0.085;
    float dz = (w1 * 0.35 - w2 * 0.45 + w3 * 0.20) * 0.085;
    return safeNormalize(vec3(dx, 1.0, dz));
}

void main() {
    vec4 tex = texture2D(texture, vTexcoord) * vColor;
    if (tex.a < 0.01) discard;

    vec3 N = safeNormalize(vWorldNormal);
    vec3 viewWorldDir = safeNormalize(vWorldPos);
    vec3 sunDir = safeNormalize((gbufferModelViewInverse * vec4(sunPosition, 0.0)).xyz);
    vec3 lightDir = safeNormalize((gbufferModelViewInverse * vec4(shadowLightPosition, 0.0)).xyz);

    vec3 zen, hor, lCol, aSky;
    getAtmosphere(sunDir.y, rainStrength, zen, hor, lCol, aSky);

    float torchLight = clamp((vLightmap.x - 0.03125) / 0.9375, 0.0, 1.0);
    float skyLight = clamp((vLightmap.y - 0.03125) / 0.9375, 0.0, 1.0);
    float dist = length(vViewPos);

    vec3 color;
    float alpha = tex.a;

#ifdef REALISTIC_WATER
    if (vIsWater > 0.5) {
        vec3 absP = vWorldPos + cameraPosition;
        vec3 wN = (abs(N.y) > 0.5) ? getWaterNormal(absP.xz, frameTimeCounter) : N;

        vec3 R = reflect(viewWorldDir, wN);
        R.y = abs(R.y);
        vec3 skyRefl = computeSky(R, sunDir, rainStrength) * (0.25 + 0.75 * skyLight);

        float cosTheta = max(dot(-viewWorldDir, wN), 0.0);
        float fresnel = clamp(0.05 + 0.95 * pow(1.0 - cosTheta, 4.0), 0.0, 1.0);

        vec3 baseTint = srgbToLinear(vColor.rgb) * vec3(0.06, 0.24, 0.30);
        vec3 waterBody = baseTint * (aSky * skyLight + lCol * 0.45 * skyLight + vec3(0.04));

        vec3 H = safeNormalize(lightDir - viewWorldDir);
        float spec = pow(max(dot(wN, H), 0.0001), 160.0) * 3.2 * skyLight;
        vec3 specular = lCol * spec;

        vec3 torchCol = vec3(1.0, 0.55, 0.20) * pow(max(torchLight, 0.0001), 2.3);
        color = mix(waterBody, skyRefl, fresnel) + specular + waterBody * torchCol;
        alpha = mix(0.46, 0.92, fresnel);
    } else
#endif
    {
        vec3 albedo = srgbToLinear(tex.rgb);
        float diffuse = max(dot(N, lightDir), 0.0);
        vec3 torchCol = vec3(1.0, 0.54, 0.18) * pow(max(torchLight, 0.0001), 2.3) * 1.8;
        color = albedo * (aSky * 0.55 * skyLight + lCol * diffuse * skyLight + torchCol + vec3(0.05));

        vec3 R = reflect(viewWorldDir, N);
        float fresnel = 0.06 + 0.45 * pow(1.0 - max(dot(-viewWorldDir, N), 0.0), 3.0);
        color += computeSky(R, sunDir, rainStrength) * fresnel * 0.35 * skyLight;
    }

    float fogF = smoothstep(far * 0.52, far * 0.98, dist);
    vec3 fogCol = computeSky(safeNormalize(vec3(viewWorldDir.x, max(viewWorldDir.y, 0.02), viewWorldDir.z)), sunDir, rainStrength);
    color = mix(color, fogCol, fogF);

    color = linearToSRGB(acesToneMap(color));
    gl_FragColor = vec4(color, alpha);
}
