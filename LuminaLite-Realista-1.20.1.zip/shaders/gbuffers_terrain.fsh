#version 120
#include "/lib/settings.glsl"
#include "/lib/common.glsl"

/* DRAWBUFFERS:0 */
uniform sampler2D texture;
uniform sampler2D shadowtex0;
uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform vec3 shadowLightPosition;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;
uniform float rainStrength;
uniform int isEyeInWater;
uniform float far;
uniform float nightVision;
uniform int heldBlockLightValue;
uniform int heldBlockLightValue2;

varying vec2 vTexcoord;
varying vec2 vLightmap;
varying vec4 vColor;
varying vec3 vWorldNormal;
varying vec3 vViewPos;
varying vec3 vWorldPos;
varying vec3 vShadowClip;
varying float vBlockType;

#ifdef SHADOWS
float getShadow(vec3 sClip, float NdotL) {
    float edgeDist = max(abs(sClip.x), abs(sClip.y));
    if (edgeDist >= 0.995) return 1.0;
    vec2 uv = distortShadow(sClip.xy) * 0.5 + 0.5;
    float depth = (sClip.z * 0.5) * 0.5 + 0.5;
    if (depth <= 0.001 || depth >= 0.999) return 1.0;

    float bias = 0.0007 + 0.0014 * (1.0 - max(NdotL, 0.0));
    float off = 1.15 / float(shadowMapResolution);
    float lit = 0.0;
    lit += step(depth - bias, texture2D(shadowtex0, uv + vec2( off,  off)).r);
    lit += step(depth - bias, texture2D(shadowtex0, uv + vec2(-off,  off)).r);
    lit += step(depth - bias, texture2D(shadowtex0, uv + vec2( off, -off)).r);
    lit += step(depth - bias, texture2D(shadowtex0, uv + vec2(-off, -off)).r);
    lit *= 0.25;

    return mix(lit, 1.0, smoothstep(0.76, 0.99, edgeDist));
}
#endif

void main() {
    vec4 tex = texture2D(texture, vTexcoord) * vColor;
    if (tex.a < 0.1) discard;

    vec3 albedo = srgbToLinear(tex.rgb);
    vec3 N = safeNormalize(vWorldNormal);
    vec3 viewWorldDir = safeNormalize(vWorldPos);
    vec3 sunDir = safeNormalize((gbufferModelViewInverse * vec4(sunPosition, 0.0)).xyz);
    vec3 lightDir = safeNormalize((gbufferModelViewInverse * vec4(shadowLightPosition, 0.0)).xyz);

    vec3 zen, hor, lCol, aSky;
    getAtmosphere(sunDir.y, rainStrength, zen, hor, lCol, aSky);

    float torchLight = clamp((vLightmap.x - 0.03125) / 0.9375, 0.0, 1.0);
    float skyLight = clamp((vLightmap.y - 0.03125) / 0.9375, 0.0, 1.0);

    float heldVal = max(float(heldBlockLightValue), float(heldBlockLightValue2)) / 15.0;
    float dist = length(vViewPos);
    float dynTorch = max(0.0, heldVal - dist / 14.0);
    torchLight = max(torchLight, dynTorch);

    float NdotL = dot(N, lightDir);
    float isFoliage = float(vBlockType > 0.5 && vBlockType < 1.5);
    float isEmissive = float(vBlockType > 1.5);

    float diffuse = max(NdotL, 0.0);
    if (isFoliage > 0.5) {
        diffuse = max(diffuse, 0.48);
    }

    float shadow = 1.0;
#ifdef SHADOWS
    if (skyLight > 0.05 && (diffuse > 0.0 || isFoliage > 0.5)) {
        shadow = getShadow(vShadowClip, NdotL);
    }
#endif
    shadow *= smoothstep(0.04, 0.38, skyLight);

    float hemi = N.y * 0.5 + 0.5;
    vec3 skyAmbient = mix(aSky * 0.32, aSky * 0.72, hemi) * (skyLight * skyLight);
    vec3 caveAmbient = vec3(0.018, 0.022, 0.030) + vec3(0.35) * nightVision;

    float torchCurve = pow(max(torchLight, 0.0001), 2.35) * 1.95;
    vec3 torchColor = vec3(1.0, 0.54, 0.18) * torchCurve;

    vec3 direct = lCol * diffuse * shadow;

    if (isFoliage > 0.5) {
        float backLit = pow(max(dot(viewWorldDir, lightDir), 0.0001), 4.0);
        direct += lCol * backLit * 0.45 * shadow;
    }

    if (isEyeInWater == 1 && skyLight > 0.25 && diffuse > 0.0) {
        vec3 absP = vWorldPos + cameraPosition;
        float c1 = sin(absP.x * 1.9 + frameTimeCounter * 2.2) * cos(absP.z * 1.9 - frameTimeCounter * 1.7);
        float c2 = sin((absP.x + absP.z) * 1.5 - frameTimeCounter * 2.5);
        float caustic = pow(max(c1 * 0.5 + c2 * 0.5 + 0.5, 0.0001), 3.0);
        direct += vec3(0.25, 0.75, 0.85) * caustic * 0.45 * shadow * skyLight;
    }

    vec3 totalLight = skyAmbient + caveAmbient + direct + torchColor;
    vec3 color = albedo * totalLight;

    if (isEmissive > 0.5) {
        color += albedo * 2.2;
    }

    if (rainStrength > 0.05 && skyLight > 0.82 && N.y > 0.65 && isFoliage < 0.5) {
        vec2 wp = (vWorldPos.xz + cameraPosition.xz) * 0.35;
        float puddle = smoothstep(0.1, 0.65, sin(wp.x) * cos(wp.y) + 0.5 * sin(wp.x * 2.3 + wp.y * 1.7));
        float wet = puddle * rainStrength * smoothstep(0.82, 0.98, skyLight);
        color *= (1.0 - wet * 0.32);
        vec3 R = reflect(viewWorldDir, N);
        vec3 refl = computeSky(R, sunDir, rainStrength);
        float fres = pow(1.0 - max(dot(-viewWorldDir, N), 0.0), 3.0);
        color = mix(color, refl * 0.9, wet * (0.18 + 0.55 * fres));
    }

    float fogF = smoothstep(far * 0.52, far * 0.98, dist);
    fogF = clamp(fogF + smoothstep(22.0, far * 1.45, dist) * (0.10 + 0.22 * rainStrength), 0.0, 1.0);
    vec3 fogCol = computeSky(safeNormalize(vec3(viewWorldDir.x, max(viewWorldDir.y, 0.02), viewWorldDir.z)), sunDir, rainStrength);
    color = mix(color, fogCol, fogF);

    color = linearToSRGB(acesToneMap(color));
    gl_FragColor = vec4(color, tex.a);
}
