#version 120
uniform mat4 gbufferModelViewInverse;
varying vec2 vTexcoord;
varying vec4 vColor;
varying vec3 vWorldPos;
varying vec3 vNormal;

void main() {
    vTexcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vColor = gl_Color;
    vec4 vp = gl_ModelViewMatrix * gl_Vertex;
    vWorldPos = (gbufferModelViewInverse * vp).xyz;
    vNormal = gl_Normal;
    gl_Position = gl_ProjectionMatrix * vp;
}
