#version 120
#include "/lib/settings.glsl"
#include "/lib/common.glsl"

/* DRAWBUFFERS:0 */
uniform sampler2D texture;
uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform float rainStrength;

varying vec2 vTexcoord;
varying vec4 vColor;
varying vec3 vWorldPos;
varying vec3 vNormal;

void main() {
    vec4 tex = texture2D(texture, vTexcoord) * vColor;
    if (tex.a < 0.05) discard;

    vec3 sunDir = safeNormalize((gbufferModelViewInverse * vec4(sunPosition, 0.0)).xyz);
    vec3 zen, hor, lCol, aSky;
    getAtmosphere(sunDir.y, rainStrength, zen, hor, lCol, aSky);

    float shade = 0.65 + 0.35 * clamp(vNormal.y * 0.5 + 0.5, 0.0, 1.0);
    vec3 cloudCol = (hor * 0.95 + lCol * 0.35) * shade;
    cloudCol = linearToSRGB(acesToneMap(cloudCol));

    float dist = length(vWorldPos.xz);
    float fade = 1.0 - smoothstep(140.0, 290.0, dist);
    gl_FragColor = vec4(cloudCol, tex.a * 0.82 * fade);
}
