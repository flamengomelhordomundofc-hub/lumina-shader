#define SHADOWS
#define GODRAYS
#define BLOOM
#define REALISTIC_WATER
#define WAVING_FOLIAGE
#define VIBRANCE

const int shadowMapResolution = 1024; // [512 1024 2048]
const float shadowDistance = 72.0;
const float shadowDistanceRenderMul = 1.0;
const float shadowIntervalSize = 2.0;
const float sunPathRotation = -30.0;
const float ambientOcclusionLevel = 0.75;
