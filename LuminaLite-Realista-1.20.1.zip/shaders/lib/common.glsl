vec3 safeNormalize(vec3 v) {
    float l2 = dot(v, v);
    return (l2 > 0.000001) ? v * inversesqrt(l2) : vec3(0.0, 1.0, 0.0);
}

vec3 srgbToLinear(vec3 c) {
    return pow(max(c, vec3(0.0001)), vec3(2.2));
}

vec3 linearToSRGB(vec3 c) {
    return pow(max(c, vec3(0.0001)), vec3(0.454545));
}

vec3 acesToneMap(vec3 x) {
    const float a = 2.51;
    const float b = 0.03;
    const float c = 2.43;
    const float d = 0.59;
    const float e = 0.14;
    return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0);
}

vec2 distortShadow(vec2 p) {
    float dist = length(p);
    return p / mix(1.0, dist, 0.80);
}

void getAtmosphere(float sunH, float rain, out vec3 zenith, out vec3 horizon, out vec3 lightCol, out vec3 ambSky) {
    float dayF = smoothstep(-0.08, 0.22, sunH);
    float sunsetF = smoothstep(-0.14, 0.04, sunH) * (1.0 - smoothstep(0.06, 0.34, sunH));

    vec3 dayZen = vec3(0.07, 0.24, 0.72);
    vec3 dayHor = vec3(0.42, 0.68, 0.96);
    vec3 setZen = vec3(0.09, 0.13, 0.36);
    vec3 setHor = vec3(1.15, 0.36, 0.10);
    vec3 nitZen = vec3(0.008, 0.015, 0.042);
    vec3 nitHor = vec3(0.022, 0.036, 0.075);

    zenith = mix(nitZen, dayZen, dayF);
    zenith = mix(zenith, setZen, sunsetF * 0.85);

    horizon = mix(nitHor, dayHor, dayF);
    horizon = mix(horizon, setHor, sunsetF * 0.92);

    vec3 rainZen = mix(vec3(0.015, 0.02, 0.03), vec3(0.16, 0.19, 0.23), dayF);
    vec3 rainHor = mix(vec3(0.025, 0.03, 0.04), vec3(0.28, 0.31, 0.35), dayF);
    zenith = mix(zenith, rainZen, rain * 0.85);
    horizon = mix(horizon, rainHor, rain * 0.85);

    vec3 sunCol = mix(vec3(1.55, 0.55, 0.18), vec3(1.55, 1.42, 1.24), smoothstep(0.0, 0.30, sunH));
    vec3 moonCol = vec3(0.18, 0.26, 0.44);
    lightCol = (sunH >= 0.0) ? sunCol : moonCol;
    lightCol *= smoothstep(0.0, 0.12, abs(sunH));
    lightCol *= (1.0 - rain * 0.78);

    ambSky = mix(zenith, horizon, 0.45);
}

vec3 computeSky(vec3 dir, vec3 sunDir, float rain) {
    vec3 zen, hor, lCol, aSky;
    getAtmosphere(sunDir.y, rain, zen, hor, lCol, aSky);

    float up = clamp(dir.y, 0.0, 1.0);
    float grad = pow(max(up, 0.0001), 0.55);
    vec3 sky = mix(hor, zen, grad);

    float below = clamp(-dir.y, 0.0, 1.0);
    sky = mix(sky, hor * 0.55, smoothstep(0.0, 0.4, below));

    float sunDot = max(dot(dir, sunDir), 0.0);
    float sunVis = smoothstep(-0.12, 0.08, sunDir.y) * (1.0 - rain * 0.9);
    vec3 glowCol = mix(vec3(1.4, 0.42, 0.10), vec3(1.2, 1.0, 0.78), smoothstep(0.0, 0.32, sunDir.y));
    sky += glowCol * pow(max(sunDot, 0.0001), 10.0) * 0.45 * sunVis;
    sky += glowCol * pow(max(sunDot, 0.0001), 140.0) * 1.8 * sunVis;

    float moonDot = max(dot(dir, -sunDir), 0.0);
    float moonVis = (1.0 - smoothstep(-0.12, 0.06, sunDir.y)) * (1.0 - rain * 0.9);
    sky += vec3(0.25, 0.36, 0.62) * pow(max(moonDot, 0.0001), 24.0) * 0.35 * moonVis;

    return sky;
}

vec3 getWaveOffset(vec3 absPos, float time, float rain, float strength) {
    float speed = 2.0 + rain * 1.8;
    float amp = (0.045 + rain * 0.04) * strength;
    float phase = absPos.x * 0.9 + absPos.z * 0.7 + absPos.y * 0.5;
    float wx = sin(time * speed + phase) * amp;
    float wz = cos(time * speed * 0.85 + phase * 1.15) * amp * 0.8;
    return vec3(wx, 0.0, wz);
}
