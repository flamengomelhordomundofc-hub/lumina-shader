#version 120
#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjection;
uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform float viewWidth;
uniform float viewHeight;
uniform float frameTimeCounter;
uniform float rainStrength;
uniform int isEyeInWater;
uniform float near;
uniform float far;

varying vec2 vTexcoord;

float linearizeDepth(float d) {
    return (2.0 * near * far) / max(far + near - (d * 2.0 - 1.0) * (far - near), 0.0001);
}

void main() {
    vec2 uv = vTexcoord;

    if (isEyeInWater == 1) {
        uv.x += sin(uv.y * 18.0 + frameTimeCounter * 3.0) * 0.0028;
        uv.y += cos(uv.x * 16.0 + frameTimeCounter * 2.5) * 0.0028;
        uv = clamp(uv, 0.002, 0.998);
    }

    vec3 color = texture2D(colortex0, uv).rgb;
    vec2 texel = vec2(1.0 / max(viewWidth, 1.0), 1.0 / max(viewHeight, 1.0));

#ifdef BLOOM
    vec3 glow = vec3(0.0);
    vec2 o1 = texel * 2.5;
    vec2 o2 = texel * 5.5;
    glow += max(texture2D(colortex0, clamp(uv + vec2( o1.x,  o1.y), 0.0, 1.0)).rgb - 0.72, 0.0);
    glow += max(texture2D(colortex0, clamp(uv + vec2(-o1.x,  o1.y), 0.0, 1.0)).rgb - 0.72, 0.0);
    glow += max(texture2D(colortex0, clamp(uv + vec2( o1.x, -o1.y), 0.0, 1.0)).rgb - 0.72, 0.0);
    glow += max(texture2D(colortex0, clamp(uv + vec2(-o1.x, -o1.y), 0.0, 1.0)).rgb - 0.72, 0.0);
    glow += max(texture2D(colortex0, clamp(uv + vec2( o2.x,  0.0 ), 0.0, 1.0)).rgb - 0.72, 0.0);
    glow += max(texture2D(colortex0, clamp(uv + vec2(-o2.x,  0.0 ), 0.0, 1.0)).rgb - 0.72, 0.0);
    glow += max(texture2D(colortex0, clamp(uv + vec2( 0.0,   o2.y), 0.0, 1.0)).rgb - 0.72, 0.0);
    glow += max(texture2D(colortex0, clamp(uv + vec2( 0.0,  -o2.y), 0.0, 1.0)).rgb - 0.72, 0.0);
    color += glow * 0.14;
#endif

#ifdef GODRAYS
    vec3 sunDir = safeNormalize((gbufferModelViewInverse * vec4(sunPosition, 0.0)).xyz);
    float sunVis = smoothstep(-0.04, 0.14, sunDir.y) * (1.0 - rainStrength * 0.9);
    if (sunVis > 0.01 && sunPosition.z < -0.5) {
        vec4 sunClip = gbufferProjection * vec4(sunPosition, 1.0);
        if (sunClip.w > 0.001) {
            vec2 sunUV = (sunClip.xy / sunClip.w) * 0.5 + 0.5;
            float screenFade = 1.0 - smoothstep(0.15, 1.25, length(sunUV - vec2(0.5)));
            if (screenFade > 0.01) {
                vec2 delta = (sunUV - uv) * 0.11;
                float jitter = fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453);
                vec2 rayUV = uv + delta * jitter;
                float rays = 0.0;
                float decay = 1.0;
                for (int i = 0; i < 8; i++) {
                    rayUV += delta;
                    if (rayUV.x > 0.0 && rayUV.x < 1.0 && rayUV.y > 0.0 && rayUV.y < 1.0) {
                        float d = texture2D(depthtex0, rayUV).r;
                        rays += step(0.9998, d) * decay;
                    }
                    decay *= 0.84;
                }
                vec3 rayCol = mix(vec3(1.0, 0.48, 0.18), vec3(1.0, 0.90, 0.70), smoothstep(0.0, 0.35, sunDir.y));
                color += rayCol * (rays * 0.048) * sunVis * screenFade;
            }
        }
    }
#endif

    if (isEyeInWater == 1) {
        float depth = linearizeDepth(texture2D(depthtex0, uv).r);
        float waterFog = clamp(1.0 - exp(-depth * 0.045), 0.0, 0.88);
        color = mix(color, vec3(0.04, 0.24, 0.34), waterFog);
    }

#ifdef VIBRANCE
    float luma = dot(color, vec3(0.2126, 0.7152, 0.0722));
    float maxC = max(color.r, max(color.g, color.b));
    float minC = min(color.r, min(color.g, color.b));
    float sat = maxC - minC;
    color = mix(vec3(luma), color, 1.0 + (1.0 - sat) * 0.24);
#endif

    vec2 vigPos = vTexcoord - vec2(0.5);
    float vig = 1.0 - dot(vigPos, vigPos) * 0.36;
    color *= clamp(vig, 0.78, 1.0);

    gl_FragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
